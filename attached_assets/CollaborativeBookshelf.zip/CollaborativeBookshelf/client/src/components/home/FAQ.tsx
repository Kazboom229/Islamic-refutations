import { useState } from "react";
import { useTranslation } from "react-i18next";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { AIChat } from '../ui/ai-chat';

interface FAQItem {
  question: string;
  answer: string;
}

export default function FAQ() {
  const { t } = useTranslation();
  const [activeItem, setActiveItem] = useState<string | null>("item-0");

  const faqItems: FAQItem[] = [
    {
      question: "What is the purpose of this platform?",
      answer: "This platform serves as a comprehensive resource center providing evidence-based refutations to misconceptions about Islam. It hosts articles, presentations, interactive diagrams, and scholarly references to help seekers of truth find accurate information about Islamic beliefs and practices."
    },
    {
      question: "How do I navigate the different sections?",
      answer: "You can use the main navigation menu at the top of the site to access different sections. The \"Why Islam\" section provides evidence for Islamic beliefs, \"Refutations\" addresses common misconceptions, \"Multimedia\" contains visual resources, and \"Submit Question\" allows you to ask your own questions."
    },
    {
      question: "Who provides the answers to submitted questions?",
      answer: "Questions are reviewed and researched by a team of scholars with expertise in Islamic studies, comparative religion, philosophy, history, and science. Each response is thoroughly vetted using authentic Islamic sources and scholarly consensus where applicable."
    },
    {
      question: "Is all content available in both English and Somali?",
      answer: "Yes, all content is available in both English and Somali. You can switch between languages using the language toggle in the top navigation bar. We're committed to making this knowledge accessible to speakers of both languages."
    },
    {
      question: "How can I contribute to this project?",
      answer: "We welcome contributions! You can help by submitting quality questions, sharing the site with others, providing feedback for improvement, or contacting us about collaboration opportunities if you have expertise in relevant fields."
    }
  ];

  return (
    <section id="faq" className="py-16 bg-gray-50 dark:bg-slate-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-amber-500 text-sm font-medium uppercase tracking-wider">Quick Answers</span>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2 mb-4">{t('faq.title')}</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            {t('faq.description')}
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion 
            type="single" 
            collapsible 
            value={activeItem || undefined}
            onValueChange={(value) => setActiveItem(value)}
            className="space-y-4"
          >
            {faqItems.map((item, index) => (
              <AccordionItem 
                key={`item-${index}`} 
                value={`item-${index}`}
                className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden bg-white dark:bg-slate-800"
              >
                <AccordionTrigger className="px-6 py-4 hover:no-underline hover:bg-gray-50 dark:hover:bg-slate-700">
                  <span className="font-medium text-gray-900 dark:text-white text-left">
                    {item.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="px-6 py-4 bg-gray-50 dark:bg-slate-700/50 text-gray-600 dark:text-gray-300">
                  {item.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <div className="mt-8">
            <h2 className="text-2xl font-bold mb-4">{t('ai.askAnything')}</h2>
            <AIChat />
          </div>
        </div>
      </div>
    </section>
  );
}