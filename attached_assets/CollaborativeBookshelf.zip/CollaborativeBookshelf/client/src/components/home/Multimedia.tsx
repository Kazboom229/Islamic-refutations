import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { MediaCard } from "../ui/media-card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const MEDIA_TYPES = [
  { id: 'all', label: 'All Media' },
  { id: 'presentation', label: 'Presentations' },
  { id: '3d', label: '3D Diagrams' },
  { id: 'infographic', label: 'Infographics' },
  { id: 'pdf', label: 'PDFs & eBooks' },
  { id: 'video', label: 'Videos' },
  { id: 'interactive', label: 'Interactive' }
];

export default function Multimedia() {
  const { t } = useTranslation();
  const [selectedType, setSelectedType] = useState('all');
  
  // Fetch multimedia items
  const { data: mediaItems, isLoading } = useQuery({
    queryKey: ['/api/media', selectedType],
    queryFn: async () => {
      const url = selectedType === 'all' 
        ? '/api/media' 
        : `/api/media?type=${selectedType}`;
      
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch media');
      return res.json();
    }
  });
  
  // Fallback demo data (will be replaced by actual API data)
  const demoMediaItems = [
    {
      id: 1,
      title: "Evidence for God's Existence",
      description: "A comprehensive presentation on philosophical and scientific arguments for the existence of God.",
      type: "presentation",
      imageUrl: "https://images.unsplash.com/photo-1603832948453-9a195c1adc9f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 1289,
      downloads: 328,
      duration: "45 min",
      url: "/media/presentation/1"
    },
    {
      id: 2,
      title: "Universe Creation Model",
      description: "Interactive 3D model showing the creation of the universe and its alignment with Qur'anic descriptions.",
      type: "3d",
      imageUrl: "https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 1243,
      url: "/media/3d/2"
    },
    {
      id: 3,
      title: "Common Misconceptions Refuted",
      description: "Comprehensive research paper addressing the top 50 misconceptions about Islam with scholarly references.",
      type: "pdf",
      imageUrl: "https://images.unsplash.com/photo-1471107340929-a87cd0f5b5f3?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 3476,
      downloads: 5782,
      url: "/media/pdf/3"
    },
    {
      id: 4,
      title: "Women's Rights in Islam",
      description: "Visual comparison of women's rights historically and in modern times, addressing common misconceptions.",
      type: "infographic",
      imageUrl: "https://images.unsplash.com/photo-1551503766-ac63dfa6401c?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 2467,
      downloads: 893,
      url: "/media/infographic/4"
    },
    {
      id: 5,
      title: "The Miracle of the Qur'an",
      description: "A detailed explanation of the linguistic, scientific, and historical miracles in the Qur'an.",
      type: "video",
      imageUrl: "https://images.unsplash.com/photo-1551184451-76b792a6e5f1?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 7823,
      duration: "32 min",
      url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    },
    {
      id: 6,
      title: "Cosmological Calculator",
      description: "Interactive calculator demonstrating the fine-tuning argument and probability of random universe creation.",
      type: "interactive",
      imageUrl: "https://images.unsplash.com/photo-1580927752452-89d86da3fa0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      views: 1123,
      sourceCode: true,
      url: "/media/interactive/6"
    }
  ];
  
  // Use demo data if API call fails or isn't ready
  const displayMedia = mediaItems || demoMediaItems;
  
  return (
    <section id="multimedia" className="py-16 bg-gray-50 dark:bg-slate-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-amber-500 text-sm font-medium uppercase tracking-wider">Resource Library</span>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2 mb-4">{t('multimedia.title')}</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            {t('multimedia.description')}
          </p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="all" className="mb-8" onValueChange={setSelectedType}>
          <TabsList className="flex justify-center overflow-x-auto hide-scrollbar gap-2 h-auto p-1">
            {MEDIA_TYPES.map(type => (
              <TabsTrigger 
                key={type.id} 
                value={type.id}
                className="px-4 py-2 data-[state=active]:bg-amber-500 data-[state=active]:text-white"
              >
                {type.label}
              </TabsTrigger>
            ))}
          </TabsList>
          
          <TabsContent value="all" className="mt-6">
            {isLoading ? (
              <div className="text-center py-20">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500"></div>
                <p className="mt-4 text-gray-500 dark:text-gray-400">Loading media...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
                {displayMedia.map((item: any) => (
                  <MediaCard 
                    key={item.id}
                    id={item.id}
                    title={item.title}
                    description={item.description}
                    type={item.type}
                    imageUrl={item.imageUrl}
                    views={item.views}
                    downloads={item.downloads}
                    duration={item.duration}
                    sourceCode={item.sourceCode}
                    url={item.url}
                  />
                ))}
              </div>
            )}
          </TabsContent>
          
          {/* Create a content for each tab, but they'll show the same component with filtered data */}
          {MEDIA_TYPES.slice(1).map(type => (
            <TabsContent key={type.id} value={type.id} className="mt-6">
              {isLoading ? (
                <div className="text-center py-20">
                  <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500"></div>
                  <p className="mt-4 text-gray-500 dark:text-gray-400">Loading {type.label.toLowerCase()}...</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
                  {displayMedia
                    .filter((item: any) => item.type === type.id)
                    .map((item: any) => (
                      <MediaCard 
                        key={item.id}
                        id={item.id}
                        title={item.title}
                        description={item.description}
                        type={item.type}
                        imageUrl={item.imageUrl}
                        views={item.views}
                        downloads={item.downloads}
                        duration={item.duration}
                        sourceCode={item.sourceCode}
                        url={item.url}
                      />
                    ))}
                </div>
              )}
            </TabsContent>
          ))}
        </Tabs>

        {/* Browse Media */}
        <div className="text-center">
          <Button asChild className="bg-blue-800 hover:bg-blue-900 gap-2">
            <Link href="/media">
              <span>Browse full media library</span>
              <i className="ri-arrow-right-line"></i>
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
