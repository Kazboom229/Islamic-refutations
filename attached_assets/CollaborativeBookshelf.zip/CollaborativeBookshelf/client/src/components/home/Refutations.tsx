import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Eye, Bookmark } from "lucide-react";

const CATEGORIES = [
  { id: 'all', label: 'All Categories', color: 'amber' },
  { id: 'philosophical', label: 'Philosophical', color: 'blue' },
  { id: 'historical', label: 'Historical', color: 'green' },
  { id: 'quranic', label: 'Qur\'anic', color: 'purple' },
  { id: 'ideological', label: 'Modern Ideological', color: 'red' },
  { id: 'global', label: 'Global Narratives', color: 'yellow' }
];

const getCategoryColor = (category: string) => {
  const found = CATEGORIES.find(c => c.id === category);
  return found?.color || 'gray';
};

interface RefutationCardProps {
  id: number;
  category: string;
  title: string;
  summary: string;
  views: number;
}

function RefutationCard({ id, category, title, summary, views }: RefutationCardProps) {
  const categoryColor = getCategoryColor(category);
  const colorClasses: Record<string, { bg: string, text: string }> = {
    'blue': { bg: 'bg-blue-100 dark:bg-blue-900/30', text: 'text-blue-800 dark:text-blue-200' },
    'green': { bg: 'bg-green-100 dark:bg-green-900/30', text: 'text-green-800 dark:text-green-200' },
    'purple': { bg: 'bg-purple-100 dark:bg-purple-900/30', text: 'text-purple-800 dark:text-purple-200' },
    'red': { bg: 'bg-red-100 dark:bg-red-900/30', text: 'text-red-800 dark:text-red-200' },
    'yellow': { bg: 'bg-yellow-100 dark:bg-yellow-900/30', text: 'text-yellow-800 dark:text-yellow-200' },
    'amber': { bg: 'bg-amber-100 dark:bg-amber-900/30', text: 'text-amber-800 dark:text-amber-200' },
    'gray': { bg: 'bg-gray-100 dark:bg-gray-900/30', text: 'text-gray-800 dark:text-gray-200' }
  };
  
  return (
    <Card className="bg-gray-50 dark:bg-slate-800 rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden">
      <CardContent className="p-6">
        <div className="flex justify-between items-start mb-4">
          <Badge 
            variant="outline" 
            className={`px-3 py-1 text-xs font-medium ${colorClasses[categoryColor].bg} ${colorClasses[categoryColor].text}`}
          >
            {CATEGORIES.find(c => c.id === category)?.label || category}
          </Badge>
          <Button variant="ghost" size="icon" className="text-gray-400 hover:text-amber-500">
            <Bookmark className="h-4 w-4" />
          </Button>
        </div>
        <CardTitle className="text-xl font-bold mb-3 text-gray-900 dark:text-white">
          {title}
        </CardTitle>
        <CardDescription className="text-gray-600 dark:text-gray-400 text-sm mb-4">
          {summary}
        </CardDescription>
        <div className="mt-4 flex justify-between items-center">
          <Link href={`/refutation/${id}`} className="text-amber-500 hover:underline font-medium flex items-center gap-1">
            Read full refutation <i className="ri-arrow-right-line"></i>
          </Link>
          <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
            <Eye className="mr-1 h-4 w-4" /> {views}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Refutations() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState('all');
  
  // Fetch refutations
  const { data: refutations, isLoading } = useQuery({
    queryKey: ['/api/refutations', selectedCategory],
    queryFn: async () => {
      const url = selectedCategory === 'all' 
        ? '/api/refutations' 
        : `/api/refutations?category=${selectedCategory}`;
      
      const res = await fetch(url);
      if (!res.ok) throw new Error('Failed to fetch refutations');
      return res.json();
    }
  });
  
  return (
    <section id="refutations" className="py-16 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-amber-500 text-sm font-medium uppercase tracking-wider">Addressing Misconceptions</span>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2 mb-4">{t('refutations.title')}</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            {t('refutations.description')}
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8 flex flex-wrap gap-3 justify-center">
          {CATEGORIES.map(category => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              className={selectedCategory === category.id ? "bg-amber-500 hover:bg-amber-600 text-white" : ""}
              onClick={() => setSelectedCategory(category.id)}
            >
              {category.label}
            </Button>
          ))}
        </div>

        {/* Refutations Grid */}
        {isLoading ? (
          <div className="text-center py-20">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500"></div>
            <p className="mt-4 text-gray-500 dark:text-gray-400">Loading refutations...</p>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              {refutations?.map((refutation: RefutationCardProps) => (
                <RefutationCard
                  key={refutation.id}
                  id={refutation.id}
                  category={refutation.category}
                  title={refutation.title}
                  summary={refutation.summary}
                  views={refutation.views}
                />
              ))}
            </div>

            {/* Load More */}
            {refutations?.length > 0 && (
              <div className="text-center">
                <Button 
                  variant="outline"
                  size="lg"
                  className="gap-2"
                >
                  <span>Load more refutations</span>
                  <i className="ri-refresh-line"></i>
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
}
