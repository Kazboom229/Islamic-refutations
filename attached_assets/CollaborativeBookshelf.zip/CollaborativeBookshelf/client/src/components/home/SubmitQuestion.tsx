import { useTranslation } from "react-i18next";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";

const FormSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  email: z.string().email({ message: "Please enter a valid email address" }),
  category: z.string().min(1, { message: "Please select a category" }),
  question: z.string().min(20, { message: "Question must be at least 20 characters" }),
  attachment: z.any().optional(),
  privacy: z.boolean().refine(val => val === true, {
    message: "You must accept the privacy policy",
  }),
});

export default function SubmitQuestion() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [file, setFile] = useState<File | null>(null);
  
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      name: "",
      email: "",
      category: "",
      question: "",
      privacy: false,
    },
  });
  
  const submitMutation = useMutation({
    mutationFn: async (values: z.infer<typeof FormSchema>) => {
      // Handle file upload if there is one
      if (file) {
        const formData = new FormData();
        formData.append("file", file);
        
        // Upload the file first
        const uploadRes = await fetch("/api/upload", {
          method: "POST",
          body: formData,
          credentials: "include",
        });
        
        if (!uploadRes.ok) {
          throw new Error("File upload failed");
        }
        
        const { fileUrl } = await uploadRes.json();
        values.attachment = fileUrl;
      }
      
      // Then submit the form
      return apiRequest("POST", "/api/questions", values);
    },
    onSuccess: () => {
      toast({
        title: "Question submitted!",
        description: "We'll review your question and provide a response soon.",
      });
      form.reset();
      setFile(null);
    },
    onError: (error) => {
      toast({
        title: "Submission failed",
        description: error.message || "There was an error submitting your question. Please try again.",
        variant: "destructive",
      });
    },
  });
  
  const onSubmit = (values: z.infer<typeof FormSchema>) => {
    submitMutation.mutate(values);
  };
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selectedFile = e.target.files[0];
      // Check file size (max 10MB)
      if (selectedFile.size > 10 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select a file smaller than 10MB",
          variant: "destructive",
        });
        return;
      }
      setFile(selectedFile);
    }
  };
  
  return (
    <section id="submit" className="py-16 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="text-amber-500 text-sm font-medium uppercase tracking-wider">Get Answers</span>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2 mb-4">{t('submit.title')}</h2>
            <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              {t('submit.description')}
            </p>
          </div>

          <div className="bg-gray-50 dark:bg-slate-800 rounded-xl shadow-md p-6 md:p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700 dark:text-gray-300">Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Your name" 
                            {...field} 
                            className="bg-white dark:bg-slate-900"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700 dark:text-gray-300">Email</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Your email" 
                            type="email" 
                            {...field} 
                            className="bg-white dark:bg-slate-900"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="category"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-300">Category</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="bg-white dark:bg-slate-900">
                            <SelectValue placeholder="Select a category" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="philosophical">Philosophical Question</SelectItem>
                          <SelectItem value="historical">Historical Misconception</SelectItem>
                          <SelectItem value="quranic">Qur'anic Question</SelectItem>
                          <SelectItem value="ideological">Modern Issue</SelectItem>
                          <SelectItem value="scientific">Scientific Claim</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="question"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700 dark:text-gray-300">Your Question</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Type your question or describe the misconception in detail..." 
                          rows={5} 
                          {...field} 
                          className="bg-white dark:bg-slate-900"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div>
                  <FormLabel className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Attachment (optional)
                  </FormLabel>
                  <div className="flex items-center justify-center w-full">
                    <label 
                      htmlFor="file-upload" 
                      className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-300 dark:border-gray-600 border-dashed rounded-lg cursor-pointer bg-white dark:bg-slate-900 hover:bg-gray-50 dark:hover:bg-slate-800"
                    >
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <i className="ri-upload-cloud-line text-3xl text-gray-400 mb-2"></i>
                        <p className="mb-2 text-sm text-gray-600 dark:text-gray-400">
                          {file ? file.name : "Drop files here or click to upload"}
                        </p>
                        <p className="text-xs text-gray-500 dark:text-gray-500">
                          PDF, PNG, JPG, or GIF (MAX. 10MB)
                        </p>
                      </div>
                      <input 
                        id="file-upload" 
                        type="file" 
                        className="hidden" 
                        onChange={handleFileChange}
                        accept=".pdf,.png,.jpg,.jpeg,.gif"
                      />
                    </label>
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="privacy"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-2">
                      <FormControl>
                        <Checkbox
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="text-sm text-gray-600 dark:text-gray-400">
                          I agree to the <a href="#" className="text-amber-500 hover:underline">privacy policy</a> and understand my question may be published anonymously.
                        </FormLabel>
                        <FormMessage />
                      </div>
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  className="w-full bg-amber-500 hover:bg-amber-600 text-white font-medium flex items-center justify-center gap-2"
                  disabled={submitMutation.isPending}
                >
                  {submitMutation.isPending ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <>
                      <span>Submit Question</span>
                      <i className="ri-send-plane-line"></i>
                    </>
                  )}
                </Button>
              </form>
            </Form>
          </div>
        </div>
      </div>
    </section>
  );
}
