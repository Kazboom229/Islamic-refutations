import { Link } from "wouter";
import { useTranslation } from "react-i18next";

export default function Footer() {
  const { t } = useTranslation();
  
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <svg className="w-8 h-8 text-amber-500" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2L1 21h22L12 2zm0 4.32L18.54 19H5.46L12 6.32zm-1 8.18v-4h2v4h-2zm0 4v-2h2v2h-2z"></path>
              </svg>
              <span className="text-xl font-bold bg-gradient-to-r from-amber-500 to-emerald-500 bg-clip-text text-transparent">Haqq</span>
            </div>
            <p className="text-gray-400 mb-4">
              A comprehensive platform for Islamic knowledge, evidence, and refutations, dedicated to spreading truth and clarity.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-amber-500 transition-colors">
                <i className="ri-facebook-fill text-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-500 transition-colors">
                <i className="ri-twitter-fill text-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-500 transition-colors">
                <i className="ri-youtube-fill text-lg"></i>
              </a>
              <a href="#" className="text-gray-400 hover:text-amber-500 transition-colors">
                <i className="ri-instagram-fill text-lg"></i>
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link href="/" className="text-gray-400 hover:text-amber-500 transition-colors">Home</Link></li>
              <li><Link href="/#why-islam" className="text-gray-400 hover:text-amber-500 transition-colors">Why Islam</Link></li>
              <li><Link href="/#refutations" className="text-gray-400 hover:text-amber-500 transition-colors">Refutations</Link></li>
              <li><Link href="/#multimedia" className="text-gray-400 hover:text-amber-500 transition-colors">Multimedia</Link></li>
              <li><Link href="/#submit" className="text-gray-400 hover:text-amber-500 transition-colors">Submit Question</Link></li>
              <li><Link href="/#faq" className="text-gray-400 hover:text-amber-500 transition-colors">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li><Link href="/#refutations?category=philosophical" className="text-gray-400 hover:text-amber-500 transition-colors">Philosophical</Link></li>
              <li><Link href="/#refutations?category=historical" className="text-gray-400 hover:text-amber-500 transition-colors">Historical</Link></li>
              <li><Link href="/#refutations?category=quranic" className="text-gray-400 hover:text-amber-500 transition-colors">Qur'anic</Link></li>
              <li><Link href="/#refutations?category=ideological" className="text-gray-400 hover:text-amber-500 transition-colors">Modern Ideological</Link></li>
              <li><Link href="/#refutations?category=scientific" className="text-gray-400 hover:text-amber-500 transition-colors">Scientific</Link></li>
              <li><Link href="/#refutations?category=global" className="text-gray-400 hover:text-amber-500 transition-colors">Global Narratives</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-bold mb-4">Contact</h3>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <i className="ri-mail-line mt-1 text-amber-500"></i>
                <span className="text-gray-400">contact@haqqplatform.com</span>
              </li>
              <li className="flex items-start gap-3">
                <i className="ri-global-line mt-1 text-amber-500"></i>
                <span className="text-gray-400">www.haqqplatform.com</span>
              </li>
              <li>
                <Link href="/#submit" className="inline-block px-4 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-lg mt-2 transition-colors">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-500 text-sm">
              &copy; {new Date().getFullYear()} Haqq Platform. All rights reserved.
            </p>
            <div className="flex space-x-4 text-sm text-gray-500">
              <a href="#" className="hover:text-amber-500 transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-amber-500 transition-colors">Terms of Service</a>
              <a href="#" className="hover:text-amber-500 transition-colors">Cookie Policy</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
