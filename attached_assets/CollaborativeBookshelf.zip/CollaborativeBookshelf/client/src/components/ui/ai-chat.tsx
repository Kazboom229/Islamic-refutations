
import { useState } from 'react';
import { Button } from './button';
import { Textarea } from './textarea';
import { Card } from './card';
import { useTranslation } from 'react-i18next';

export function AIChat() {
  const { t } = useTranslation();
  const [prompt, setPrompt] = useState('');
  const [response, setResponse] = useState('');
  const [loading, setLoading] = useState(false);
  const [mode, setMode] = useState<'chat' | 'explain' | 'generate'>('chat');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      const res = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt })
      });
      
      const data = await res.json();
      setResponse(data.response);
    } catch (error) {
      console.error('AI chat error:', error);
      setResponse(t('errors.aiChatError'));
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="p-4">
      <div className="flex gap-2 mb-4">
        <Button 
          variant={mode === 'chat' ? 'default' : 'outline'}
          onClick={() => setMode('chat')}
          size="sm"
        >
          <i className="ri-chat-1-line mr-1" /> Chat
        </Button>
        <Button 
          variant={mode === 'explain' ? 'default' : 'outline'}
          onClick={() => setMode('explain')}
          size="sm"
        >
          <i className="ri-code-line mr-1" /> Explain Code
        </Button>
        <Button 
          variant={mode === 'generate' ? 'default' : 'outline'}
          onClick={() => setMode('generate')}
          size="sm"
        >
          <i className="ri-code-box-line mr-1" /> Generate Code
        </Button>
      </div>
      <form onSubmit={handleSubmit} className="space-y-4">
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
          placeholder={t('ai.promptPlaceholder')}
          className="min-h-[100px]"
        />
        <Button type="submit" disabled={loading}>
          {loading ? t('ai.thinking') : t('ai.ask')}
        </Button>
      </form>
      
      {response && (
        <div className="mt-4 p-4 bg-secondary rounded-lg">
          <p className="whitespace-pre-wrap">{response}</p>
        </div>
      )}
    </Card>
  );
}
