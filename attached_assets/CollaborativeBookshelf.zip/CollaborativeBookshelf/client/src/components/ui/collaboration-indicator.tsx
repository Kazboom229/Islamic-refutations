
import { useEffect, useState } from 'react';
import { awareness } from '@/lib/collaboration';
import { Avatar, AvatarFallback, AvatarImage } from './avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './tooltip';

export function CollaborationIndicator() {
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    const handleChange = () => {
      const states = Array.from(awareness.getStates().values());
      setUsers(states);
    };

    awareness.on('change', handleChange);
    return () => awareness.off('change', handleChange);
  }, []);

  return (
    <div className="flex -space-x-2">
      {users.map((user, i) => (
        <TooltipProvider key={i}>
          <Tooltip>
            <TooltipTrigger>
              <Avatar className="w-8 h-8 border-2 border-white dark:border-slate-900">
                <AvatarFallback>{user.name?.[0] || '?'}</AvatarFallback>
              </Avatar>
            </TooltipTrigger>
            <TooltipContent>
              <p>{user.name || 'Anonymous'}</p>
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      ))}
    </div>
  );
}
