
import { useState, useEffect } from 'react';
import { Button } from './button';
import { Card, CardContent } from './card';

interface Suggestion {
  title: string;
  content: string;
  confidence: number;
}

export function ContentSuggestions({ content }: { content: string }) {
  const [suggestions, setSuggestions] = useState<Suggestion[]>([]);
  const [loading, setLoading] = useState(false);

  const getSuggestions = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/suggestions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
      });
      const data = await response.json();
      setSuggestions(data);
    } catch (error) {
      console.error('Failed to get suggestions:', error);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-4">
      <Button 
        onClick={getSuggestions}
        disabled={loading}
        className="w-full"
      >
        {loading ? 'Getting suggestions...' : 'Get AI Suggestions'}
      </Button>
      
      {suggestions.map((suggestion, index) => (
        <Card key={index}>
          <CardContent className="p-4">
            <h3 className="font-bold">{suggestion.title}</h3>
            <p className="text-sm text-gray-600">{suggestion.content}</p>
            <div className="mt-2 text-xs text-gray-400">
              Confidence: {suggestion.confidence}%
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
