import { Button } from "@/components/ui/button";
import { useLanguageToggle } from "@/lib/hooks";

export function LanguageToggle() {
  const { language, toggleLanguage } = useLanguageToggle();
  
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={toggleLanguage}
      className="w-12"
    >
      {language === 'en' ? 'EN' : 'SO'}
    </Button>
  );
}
