
import { syncedStore } from '@syncedstore/core';
import { WebrtcProvider } from 'y-webrtc';
import { WebsocketProvider } from 'y-websocket';
import * as Y from 'yjs';

const doc = new Y.Doc();

// Create WebRTC provider for direct peer connections
const webrtcProvider = new WebrtcProvider('haqq-doc', doc, {
  signaling: ['wss://signaling.y-webrtc.dev']
});

// Create WebSocket provider for server persistence
const websocketProvider = new WebsocketProvider(
  `ws://${window.location.host}`,
  'haqq-doc',
  doc
);

// Create synced store for shared data
export const store = syncedStore({
  fragments: {},
  presence: {},
});

// Export awareness API for user presence
export const awareness = webrtcProvider.awareness;

// Set initial user data
awareness.setLocalStateField('user', {
  name: 'Anonymous User',
  color: '#' + Math.floor(Math.random()*16777215).toString(16),
});
