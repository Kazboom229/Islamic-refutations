import { useState, useEffect } from 'react';
import { useTranslation } from 'react-i18next';

// Custom hook for dark mode
export function useDarkMode() {
  const [darkMode, setDarkMode] = useState(() => {
    const savedMode = localStorage.getItem('darkMode');
    return savedMode ? JSON.parse(savedMode) : true; // Default to dark mode
  });

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return [darkMode, setDarkMode] as const;
}

// Custom hook for language toggle
export function useLanguageToggle() {
  const { i18n } = useTranslation();
  const [language, setLanguage] = useState(() => {
    const savedLanguage = localStorage.getItem('language');
    return savedLanguage || 'en'; // Default to English
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    i18n.changeLanguage(language);
  }, [language, i18n]);

  const toggleLanguage = () => {
    setLanguage(language === 'en' ? 'so' : 'en');
  };

  return { language, toggleLanguage };
}

// Custom hook for mobile menu
export function useMobileMenu() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  useEffect(() => {
    // Close mobile menu when ESC key is pressed
    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setMobileMenuOpen(false);
      }
    };

    window.addEventListener('keydown', handleEscKey);
    return () => window.removeEventListener('keydown', handleEscKey);
  }, []);

  return [mobileMenuOpen, setMobileMenuOpen] as const;
}

// Custom hook for search overlay
export function useSearchOverlay() {
  const [searchOpen, setSearchOpen] = useState(false);
  
  useEffect(() => {
    // Close search overlay when ESC key is pressed
    const handleEscKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSearchOpen(false);
      }
    };

    window.addEventListener('keydown', handleEscKey);
    return () => window.removeEventListener('keydown', handleEscKey);
  }, []);

  return [searchOpen, setSearchOpen] as const;
}
