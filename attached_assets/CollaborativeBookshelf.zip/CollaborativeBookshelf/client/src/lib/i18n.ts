import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// English translations
const enTranslations = {
  nav: {
    home: 'Home',
    whyIslam: 'Why Islam',
    refutations: 'Refutations',
    multimedia: 'Multimedia',
    submit: 'Submit Question'
  },
  hero: {
    truth: 'Truth Through Clarity',
    subtitle: 'Islam Refuted Nothing',
    description: 'A comprehensive resource center providing evidence-based refutations and knowledge on all matters related to Islam and misconceptions about it.'
  },
  categories: {
    title: 'Main Categories',
    description: 'Explore our comprehensive collection of evidence and refutations across these key areas.',
    whyIslam: 'Why Islam?',
    whyIslamDesc: 'Evidence for God, Islam, and Prophet Muhammad (ﷺ).',
    refutations: 'Refuting Misconceptions',
    refutationsDesc: 'Answers to common doubts, criticisms, and misunderstandings.',
    multimedia: 'Multimedia Library',
    multimediaDesc: 'Videos, presentations, PDFs, and interactive diagrams.',
    submit: 'Submit a Question',
    submitDesc: 'Have your doubts addressed by knowledgeable scholars.'
  },
  whyIslam: {
    title: 'Why Islam?',
    description: 'Discover the evidence for the existence of God, the truth of Islam, and the Prophethood of Muhammad (ﷺ).',
    evidence1: {
      title: 'Evidence for God',
      point1: 'The Cosmological Argument (Kalam)',
      point2: 'The Teleological Argument (Design)',
      point3: 'The Fitrah (Innate Disposition)',
      point4: 'The Moral Argument'
    },
    evidence2: {
      title: 'Truth of Islam',
      point1: 'Preservation of the Qur\'an',
      point2: 'Scientific Miracles in the Qur\'an',
      point3: 'Linguistic Miracle of the Qur\'an',
      point4: 'Prophecies in the Qur\'an'
    },
    evidence3: {
      title: 'Prophethood of Muhammad (ﷺ)',
      point1: 'Character & Moral Integrity',
      point2: 'Prophecies Made & Fulfilled',
      point3: 'Changed the Course of History',
      point4: 'Mentioned in Previous Scriptures'
    },
    interactive: {
      title: 'Explore the Evidence Interactively',
      description: 'Our interactive diagrams and presentations help visualize complex concepts and make understanding the evidences easier and more engaging.'
    }
  },
  refutations: {
    title: 'Refuting Misconceptions',
    description: 'Comprehensive responses to common doubts and criticisms about Islam, backed by evidence and scholarly analysis.'
  },
  multimedia: {
    title: 'Multimedia Archive',
    description: 'Explore our collection of presentations, 3D diagrams, infographics, and other visual resources to deepen your understanding.'
  },
  submit: {
    title: 'Submit a Question',
    description: 'Have a question, misconception, or doubt about Islam? Submit it here, and our team will research and provide a thorough response.'
  },
  faq: {
    title: 'Frequently Asked Questions',
    description: 'Get quick answers to common questions about Islam and this platform.'
  },
  common: {
    viewDetails: 'View detailed proofs',
    explore: 'Explore',
    readMore: 'Read full refutation',
    loadMore: 'Load more',
    viewAll: 'View all',
    submit: 'Submit',
    download: 'Download',
    watch: 'Watch',
    try: 'Try',
    search: 'Search'
  },
  admin: {
    login: 'Login',
    dashboard: 'Admin Dashboard',
    addContent: 'Add New Content',
    manageContent: 'Manage Content',
    uploadMedia: 'Upload Media',
    reviewSubmissions: 'Review Submissions',
    logout: 'Logout'
  }
};

// Somali translations
const soTranslations = {
  nav: {
    home: 'Bogga Hore',
    whyIslam: 'Maxay Islaamku',
    refutations: 'Jawaabo',
    multimedia: 'Muuqaallo',
    submit: 'Su\'aal Weydii'
  },
  hero: {
    truth: 'Runta Oo Cad',
    subtitle: 'Islaamka Waxba Ma Diidin',
    description: 'Bog ururiyay jawaabo iyo xogag ku saleysan cadeymaha saxda ah ee ku saabsan Islaamka iyo qalad fahamka la xiriira.'
  },
  categories: {
    title: 'Qeybaha Ugu Waaweyn',
    description: 'Baadh ururkeena balaaran ee cadeymaha iyo jawaabaha ee qeybahan muhiimka ah.',
    whyIslam: 'Maxay Islaamku?',
    whyIslamDesc: 'Cadeymaha Ilaahay, Islaamka, iyo Nabigeenna Muxamed (ﷺ).',
    refutations: 'Ka Jawaabida Khalad-fahamka',
    refutationsDesc: 'Jawaabaha su\'aalaha caadiga ah, dhaleeceynta, iyo fahamka khaldan.',
    multimedia: 'Maktabadda Muuqaalada',
    multimediaDesc: 'Muuqaalo, bandhigyo, PDF, iyo sawirro is-dhexgala.',
    submit: 'Su\'aal Soo Dir',
    submitDesc: 'Ha ka jawaabo shakigaaga culimada aqoonta leh.'
  },
  whyIslam: {
    title: 'Maxay Islaamku?',
    description: 'Hel cadeymaha jiritaanka Alle, runta Islaamka, iyo Nabinimada Muxamed (ﷺ).',
    evidence1: {
      title: 'Cadeymaha Ilaahay',
      point1: 'Doodda Koosmoolojiga (Kalam)',
      point2: 'Doodda Nidaamka (Qorsheynta)',
      point3: 'Fitrada (Dabeecadda Dahsoon)',
      point4: 'Doodda Anshaxa'
    },
    evidence2: {
      title: 'Runta Islaamka',
      point1: 'Ilaalinta Qur\'aanka',
      point2: 'Mucjisooyin Cilmiyeed ee Qur\'aanka',
      point3: 'Mucjisada Luqadeed ee Qur\'aanka',
      point4: 'Wax-sii-sheegyada Qur\'aanka'
    },
    evidence3: {
      title: 'Nabinimada Muxamed (ﷺ)',
      point1: 'Dabeecadda & Anshax Wanaagga',
      point2: 'Wax-sii-sheegyo La Sameeyay & Dhacay',
      point3: 'Wuxuu Bedelay Socodka Taariikhda',
      point4: 'Lagu Xusay Kitaabadii Hore'
    },
    interactive: {
      title: 'U Baadh Cadeymaha Si Is-dhexgal Leh',
      description: 'Sawirradayada is-dhexgalka ah iyo bandhigyadayadu waxay ka caawiyaan muujinta fikradaha adag iyo in ay ka dhigaan fahamka cadeymaha mid ka fudud oo sii xiiso badan.'
    }
  },
  refutations: {
    title: 'Ka Jawaabida Khalad-fahamka',
    description: 'Jawaabo dhammeystiran oo ku saabsan shakiyada caadiga ah iyo dhaleeceynta Islaamka, oo ku salaysan cadeyn iyo falanqayn cilmiyeed.'
  },
  multimedia: {
    title: 'Maktabadda Muuqaalada',
    description: 'Baadh ururkeenna bandhigyada, sawirrada 3D, infograafigyada, iyo ilaha kale ee muuqaalka ah si aad u qoto dhereysid fahamkaaga.'
  },
  submit: {
    title: 'Su\'aal Soo Dir',
    description: 'Ma qabtaa su\'aal, qalad faham, ama shaki ku saabsan Islaamka? Halkan ku soo gudbi, kooxdayada ayaa cilmi-baaris sameyn doonta oo bixin doonta jawaab faahfaahsan.'
  },
  faq: {
    title: 'Su\'aalaha Inta Badan La Isweydiiyo',
    description: 'Hel jawaabo degdeg ah oo ku saabsan su\'aalaha caadiga ah ee Islaamka iyo boggan.'
  },
  common: {
    viewDetails: 'Arag cadeymaha faahfaahsan',
    explore: 'Baadh',
    readMore: 'Akhri jawaabta oo dhan',
    loadMore: 'Soo rar in badan',
    viewAll: 'Arag dhamaan',
    submit: 'Soo gudbi',
    download: 'Soo dejiso',
    watch: 'Daawo',
    try: 'Isku day',
    search: 'Raadi'
  },
  admin: {
    login: 'Gal',
    dashboard: 'Guddiga Maamulka',
    addContent: 'Ku Dar Waxyaabo Cusub',
    manageContent: 'Maamul Waxyaabaha',
    uploadMedia: 'Soo Rar Muuqaalada',
    reviewSubmissions: 'Dib u Eeg Soo Gudbinta',
    logout: 'Ka Bax'
  }
};

// Initialize i18next
i18n
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslations },
      so: { translation: soTranslations }
    },
    lng: 'en',
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
