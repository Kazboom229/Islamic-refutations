import { useState, useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Edit, Trash2, MoreVertical, Plus, FileText, Image, MessageSquare, Eye, EyeOff } from "lucide-react";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("content");
  const [itemToDelete, setItemToDelete] = useState<{ id: number, type: string } | null>(null);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    // Check if user is logged in as admin
    const adminToken = sessionStorage.getItem("adminToken");
    
    if (!adminToken) {
      navigate("/admin");
      return;
    }
    
    setToken(adminToken);
  }, [navigate]);

  // Fetch content items
  const { data: contents, isLoading: isLoadingContents } = useQuery({
    queryKey: ['/api/admin/contents'],
    queryFn: async () => {
      if (!token) return [];
      const res = await fetch('/api/admin/contents', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) throw new Error('Failed to fetch contents');
      return res.json();
    },
    enabled: !!token
  });

  // Fetch media items
  const { data: mediaItems, isLoading: isLoadingMedia } = useQuery({
    queryKey: ['/api/admin/media'],
    queryFn: async () => {
      if (!token) return [];
      const res = await fetch('/api/admin/media', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) throw new Error('Failed to fetch media');
      return res.json();
    },
    enabled: !!token
  });

  // Fetch questions
  const { data: questions, isLoading: isLoadingQuestions } = useQuery({
    queryKey: ['/api/admin/questions'],
    queryFn: async () => {
      if (!token) return [];
      const res = await fetch('/api/admin/questions', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) throw new Error('Failed to fetch questions');
      return res.json();
    },
    enabled: !!token
  });

  // Delete content mutation
  const deleteContentMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/admin/content/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/contents'] });
      toast({
        title: "Content deleted",
        description: "The content has been successfully deleted."
      });
      setItemToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete content: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Delete media mutation
  const deleteMediaMutation = useMutation({
    mutationFn: async (id: number) => {
      return apiRequest("DELETE", `/api/admin/media/${id}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/media'] });
      toast({
        title: "Media deleted",
        description: "The media item has been successfully deleted."
      });
      setItemToDelete(null);
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to delete media: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  // Toggle content published status
  const togglePublishedMutation = useMutation({
    mutationFn: async ({ id, published, type }: { id: number, published: boolean, type: string }) => {
      const endpoint = type === 'content' ? `/api/admin/content/${id}` : `/api/admin/media/${id}`;
      return apiRequest("PUT", endpoint, { published });
    },
    onSuccess: (_, variables) => {
      const { type } = variables;
      if (type === 'content') {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/contents'] });
      } else {
        queryClient.invalidateQueries({ queryKey: ['/api/admin/media'] });
      }
      toast({
        title: "Status updated",
        description: `The item is now ${variables.published ? 'published' : 'unpublished'}.`
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update status: ${error.message}`,
        variant: "destructive"
      });
    }
  });

  const handleDelete = () => {
    if (!itemToDelete) return;
    
    if (itemToDelete.type === 'content') {
      deleteContentMutation.mutate(itemToDelete.id);
    } else if (itemToDelete.type === 'media') {
      deleteMediaMutation.mutate(itemToDelete.id);
    }
  };

  const handleTogglePublished = (id: number, currentStatus: boolean, type: string) => {
    togglePublishedMutation.mutate({
      id,
      published: !currentStatus,
      type
    });
  };

  if (!token) {
    return null; // Will redirect to login
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">{t('admin.dashboard')}</h1>
          <p className="text-gray-600 dark:text-gray-300 mt-1">Manage your content, media, and user submissions</p>
        </div>
        <div className="flex gap-3">
          <Button asChild className="bg-amber-500 hover:bg-amber-600">
            <Link href="/admin/content/new">
              <Plus className="h-4 w-4 mr-2" /> Add New Content
            </Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="content" value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-3 mb-8">
          <TabsTrigger value="content" className="flex items-center gap-2">
            <FileText className="h-4 w-4" /> Content
          </TabsTrigger>
          <TabsTrigger value="media" className="flex items-center gap-2">
            <Image className="h-4 w-4" /> Media
          </TabsTrigger>
          <TabsTrigger value="questions" className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" /> Questions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="content">
          <Card>
            <CardHeader>
              <CardTitle>Content Management</CardTitle>
              <CardDescription>
                Manage articles, refutations, and evidence content
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingContents ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : contents?.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contents.map((content: any) => (
                      <TableRow key={content.id}>
                        <TableCell className="font-medium">{content.title_en}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{content.category}</Badge>
                        </TableCell>
                        <TableCell>{content.type}</TableCell>
                        <TableCell>
                          {content.published ? (
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200">
                              Published
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-200">
                              Draft
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{content.views}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => navigate(`/admin/content/edit/${content.id}`)}>
                                <Edit className="h-4 w-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleTogglePublished(content.id, content.published, 'content')}>
                                {content.published ? (
                                  <>
                                    <EyeOff className="h-4 w-4 mr-2" /> Unpublish
                                  </>
                                ) : (
                                  <>
                                    <Eye className="h-4 w-4 mr-2" /> Publish
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                className="text-red-600 focus:text-red-600" 
                                onClick={() => setItemToDelete({ id: content.id, type: 'content' })}
                              >
                                <Trash2 className="h-4 w-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No content items found</p>
                  <Button asChild>
                    <Link href="/admin/content/new">
                      <Plus className="h-4 w-4 mr-2" /> Add Content
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="media">
          <Card>
            <CardHeader>
              <CardTitle>Media Management</CardTitle>
              <CardDescription>
                Manage presentations, PDFs, 3D models, and other media
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingMedia ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : mediaItems?.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Title</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Views</TableHead>
                      <TableHead>Downloads</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {mediaItems.map((media: any) => (
                      <TableRow key={media.id}>
                        <TableCell className="font-medium">{media.title_en}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{media.type}</Badge>
                        </TableCell>
                        <TableCell>
                          {media.published ? (
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200">
                              Published
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-200">
                              Draft
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{media.views}</TableCell>
                        <TableCell>{media.downloads || 0}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuLabel>Actions</DropdownMenuLabel>
                              <DropdownMenuItem onClick={() => navigate(`/admin/media/edit/${media.id}`)}>
                                <Edit className="h-4 w-4 mr-2" /> Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => handleTogglePublished(media.id, media.published, 'media')}>
                                {media.published ? (
                                  <>
                                    <EyeOff className="h-4 w-4 mr-2" /> Unpublish
                                  </>
                                ) : (
                                  <>
                                    <Eye className="h-4 w-4 mr-2" /> Publish
                                  </>
                                )}
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                className="text-red-600 focus:text-red-600" 
                                onClick={() => setItemToDelete({ id: media.id, type: 'media' })}
                              >
                                <Trash2 className="h-4 w-4 mr-2" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">No media items found</p>
                  <Button asChild>
                    <Link href="/admin/media/new">
                      <Plus className="h-4 w-4 mr-2" /> Add Media
                    </Link>
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="questions">
          <Card>
            <CardHeader>
              <CardTitle>User Questions</CardTitle>
              <CardDescription>
                Review and respond to submitted questions
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingQuestions ? (
                <div className="space-y-2">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : questions?.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Question</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Submitted</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {questions.map((question: any) => (
                      <TableRow key={question.id}>
                        <TableCell className="font-medium">{question.name}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{question.category}</Badge>
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{question.question}</TableCell>
                        <TableCell>
                          {question.status === "pending" && (
                            <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-200">
                              Pending
                            </Badge>
                          )}
                          {question.status === "answered" && (
                            <Badge className="bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-200">
                              Answered
                            </Badge>
                          )}
                          {question.status === "rejected" && (
                            <Badge variant="outline" className="bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-200">
                              Rejected
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>{new Date(question.createdAt).toLocaleDateString()}</TableCell>
                        <TableCell className="text-right">
                          <Button asChild variant="ghost" size="sm">
                            <Link href={`/admin/question/${question.id}`}>
                              View Details
                            </Link>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400">No questions have been submitted yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!itemToDelete} onOpenChange={(open) => !open && setItemToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the {itemToDelete?.type} item.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleDelete}
              className="bg-red-600 hover:bg-red-700 focus:ring-red-600"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
