
import { WebSocketServer } from 'ws';
import { setupWSConnection } from 'y-websocket/bin/utils';
import { Server } from 'http';

export function setupCollaborationServer(httpServer: Server) {
  const wss = new WebSocketServer({ server: httpServer });
  
  wss.on('connection', (ws, req) => {
    setupWSConnection(ws, req, { docName: 'shared-doc' });
  });
}
