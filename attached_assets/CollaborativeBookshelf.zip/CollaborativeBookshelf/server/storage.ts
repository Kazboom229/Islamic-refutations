import { 
  User, InsertUser, 
  Content, InsertContent, 
  Media, InsertMedia, 
  Question, InsertQuestion,
  users, contents, media, questions
} from "@shared/schema";

// Storage interface for all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Content operations
  getContents(options?: { category?: string, type?: string, published?: boolean }): Promise<Content[]>;
  getContent(id: number): Promise<Content | undefined>;
  createContent(content: InsertContent): Promise<Content>;
  updateContent(id: number, content: Partial<InsertContent>): Promise<Content | undefined>;
  deleteContent(id: number): Promise<boolean>;
  incrementViews(id: number): Promise<void>;
  searchContents(query: string): Promise<Content[]>;
  
  // Media operations
  getMediaItems(options?: { type?: string, published?: boolean }): Promise<Media[]>;
  getMedia(id: number): Promise<Media | undefined>;
  createMedia(media: InsertMedia): Promise<Media>;
  updateMedia(id: number, media: Partial<InsertMedia>): Promise<Media | undefined>;
  deleteMedia(id: number): Promise<boolean>;
  incrementMediaViews(id: number): Promise<void>;
  incrementMediaDownloads(id: number): Promise<void>;
  
  // Question operations
  getQuestions(options?: { status?: string }): Promise<Question[]>;
  getQuestion(id: number): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: number, update: Partial<Question>): Promise<Question | undefined>;
  deleteQuestion(id: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private contents: Map<number, Content>;
  private mediaItems: Map<number, Media>;
  private questions: Map<number, Question>;
  
  private userId: number = 1;
  private contentId: number = 1;
  private mediaId: number = 1;
  private questionId: number = 1;

  constructor() {
    this.users = new Map();
    this.contents = new Map();
    this.mediaItems = new Map();
    this.questions = new Map();
    
    // Initialize with admin user
    this.createUser({
      username: "admin",
      password: "admin123", // In a real app, this would be hashed
      isAdmin: true
    });
    
    // Initialize with some content
    this.initializeData();
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Content methods
  async getContents(options?: { category?: string, type?: string, published?: boolean }): Promise<Content[]> {
    let contents = Array.from(this.contents.values());
    
    if (options) {
      if (options.category) {
        contents = contents.filter(content => content.category === options.category);
      }
      if (options.type) {
        contents = contents.filter(content => content.type === options.type);
      }
      if (options.published !== undefined) {
        contents = contents.filter(content => content.published === options.published);
      }
    }
    
    return contents;
  }
  
  async getContent(id: number): Promise<Content | undefined> {
    return this.contents.get(id);
  }
  
  async createContent(content: InsertContent): Promise<Content> {
    const id = this.contentId++;
    const now = new Date();
    const newContent: Content = {
      ...content,
      id,
      views: 0,
      createdAt: now,
      updatedAt: now
    };
    this.contents.set(id, newContent);
    return newContent;
  }
  
  async updateContent(id: number, content: Partial<InsertContent>): Promise<Content | undefined> {
    const existingContent = this.contents.get(id);
    if (!existingContent) return undefined;
    
    const updatedContent: Content = {
      ...existingContent,
      ...content,
      updatedAt: new Date()
    };
    
    this.contents.set(id, updatedContent);
    return updatedContent;
  }
  
  async deleteContent(id: number): Promise<boolean> {
    return this.contents.delete(id);
  }
  
  async incrementViews(id: number): Promise<void> {
    const content = this.contents.get(id);
    if (content) {
      content.views += 1;
      this.contents.set(id, content);
    }
  }
  
  async searchContents(query: string): Promise<Content[]> {
    query = query.toLowerCase();
    return Array.from(this.contents.values()).filter(content => {
      return (
        content.title_en.toLowerCase().includes(query) ||
        content.summary_en.toLowerCase().includes(query) ||
        content.content_en.toLowerCase().includes(query) ||
        (content.title_so && content.title_so.toLowerCase().includes(query)) ||
        (content.summary_so && content.summary_so.toLowerCase().includes(query)) ||
        (content.content_so && content.content_so.toLowerCase().includes(query)) ||
        (content.tags && content.tags.some(tag => tag.toLowerCase().includes(query)))
      );
    });
  }
  
  // Media methods
  async getMediaItems(options?: { type?: string, published?: boolean }): Promise<Media[]> {
    let mediaItems = Array.from(this.mediaItems.values());
    
    if (options) {
      if (options.type) {
        mediaItems = mediaItems.filter(item => item.type === options.type);
      }
      if (options.published !== undefined) {
        mediaItems = mediaItems.filter(item => item.published === options.published);
      }
    }
    
    return mediaItems;
  }
  
  async getMedia(id: number): Promise<Media | undefined> {
    return this.mediaItems.get(id);
  }
  
  async createMedia(media: InsertMedia): Promise<Media> {
    const id = this.mediaId++;
    const now = new Date();
    const newMedia: Media = {
      ...media,
      id,
      views: 0,
      downloads: 0,
      createdAt: now,
      updatedAt: now
    };
    this.mediaItems.set(id, newMedia);
    return newMedia;
  }
  
  async updateMedia(id: number, media: Partial<InsertMedia>): Promise<Media | undefined> {
    const existingMedia = this.mediaItems.get(id);
    if (!existingMedia) return undefined;
    
    const updatedMedia: Media = {
      ...existingMedia,
      ...media,
      updatedAt: new Date()
    };
    
    this.mediaItems.set(id, updatedMedia);
    return updatedMedia;
  }
  
  async deleteMedia(id: number): Promise<boolean> {
    return this.mediaItems.delete(id);
  }
  
  async incrementMediaViews(id: number): Promise<void> {
    const media = this.mediaItems.get(id);
    if (media) {
      media.views += 1;
      this.mediaItems.set(id, media);
    }
  }
  
  async incrementMediaDownloads(id: number): Promise<void> {
    const media = this.mediaItems.get(id);
    if (media) {
      media.downloads += 1;
      this.mediaItems.set(id, media);
    }
  }
  
  // Question methods
  async getQuestions(options?: { status?: string }): Promise<Question[]> {
    let questions = Array.from(this.questions.values());
    
    if (options && options.status) {
      questions = questions.filter(question => question.status === options.status);
    }
    
    return questions;
  }
  
  async getQuestion(id: number): Promise<Question | undefined> {
    return this.questions.get(id);
  }
  
  async createQuestion(question: InsertQuestion): Promise<Question> {
    const id = this.questionId++;
    const now = new Date();
    const newQuestion: Question = {
      ...question,
      id,
      status: "pending",
      answer: null,
      answeredBy: null,
      createdAt: now,
      updatedAt: now
    };
    this.questions.set(id, newQuestion);
    return newQuestion;
  }
  
  async updateQuestion(id: number, update: Partial<Question>): Promise<Question | undefined> {
    const question = this.questions.get(id);
    if (!question) return undefined;
    
    const updatedQuestion: Question = {
      ...question,
      ...update,
      updatedAt: new Date()
    };
    
    this.questions.set(id, updatedQuestion);
    return updatedQuestion;
  }
  
  async deleteQuestion(id: number): Promise<boolean> {
    return this.questions.delete(id);
  }
  
  // Initialize with sample data for testing
  private initializeData() {
    // Create sample refutations
    this.createContent({
      title_en: "The Problem of Evil",
      title_so: "Dhibaatada Shar",
      summary_en: "Addressing the common objection about why evil exists if God is all-powerful and all-good.",
      summary_so: "Ka jawaabida su'aalaha caadiga ah ee ku saabsan sababta shar u jiro haddii Ilaahay yahay mid awood leh oo dhan wanaag ah.",
      content_en: "This is a detailed refutation of the problem of evil...",
      content_so: "Tani waa jawaab faahfaahsan oo ku saabsan dhibaatada shar...",
      category: "philosophical",
      type: "refutation",
      tags: ["philosophy", "theodicy", "evil"],
      featured: true,
      published: true
    });
    
    this.createContent({
      title_en: "Age of Aisha (RA)",
      title_so: "Da'da Aisha (RA)",
      summary_en: "Examining historical context, cultural norms, and scholarly analyses of Aisha's age at marriage.",
      summary_so: "Baadhitaanka xaaladda taariikhiga ah, dhaqamada dhaqanka, iyo falanqaynta aqoonta ee da'da Aisha markii la guursaday.",
      content_en: "This is a detailed examination of the historical context...",
      content_so: "Tani waa baadhitaan faahfaahsan oo ku saabsan xaaladda taariikhiga ah...",
      category: "historical",
      type: "refutation",
      tags: ["history", "marriage", "aisha"],
      featured: true,
      published: true
    });
    
    // Create sample media items
    this.createMedia({
      title_en: "Evidence for God's Existence",
      title_so: "Caddaynta Jiritaanka Ilaahay",
      description_en: "A comprehensive presentation on philosophical and scientific arguments for the existence of God.",
      description_so: "Bandhig dhammaystiran oo ku saabsan doodaha falsafadeed iyo cilmiyeed ee jiritaanka Ilaahay.",
      type: "presentation",
      url: "/media/presentation/1",
      imageUrl: "https://images.unsplash.com/photo-1603832948453-9a195c1adc9f?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      duration: "45 min",
      featured: true,
      published: true
    });
    
    this.createMedia({
      title_en: "Universe Creation Model",
      title_so: "Qaabka Abuurista Caalamka",
      description_en: "Interactive 3D model showing the creation of the universe and its alignment with Qur'anic descriptions.",
      description_so: "Model 3D ah oo muujinaya abuurista caalamka iyo iswaafaqsanaantiisa tilmaamaha Qur'aanka.",
      type: "3d",
      url: "/media/3d/2",
      imageUrl: "https://images.unsplash.com/photo-1519681393784-d120267933ba?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      featured: true,
      published: true
    });
  }
}

export const storage = new MemStorage();
