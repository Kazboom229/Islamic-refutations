import { useTranslation } from "react-i18next";
import { Link } from "wouter";

interface CategoryCardProps {
  title: string;
  description: string;
  imageUrl: string;
  link: string;
}

function CategoryCard({ title, description, imageUrl, link }: CategoryCardProps) {
  return (
    <div className="bg-gray-50 dark:bg-slate-800 rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden">
      <div className="h-36 overflow-hidden">
        <img 
          src={imageUrl} 
          alt={title} 
          className="w-full h-full object-cover transform hover:scale-105 transition-transform"
        />
      </div>
      <div className="p-5">
        <h3 className="text-xl font-bold mb-2 text-gray-900 dark:text-white">{title}</h3>
        <p className="text-gray-600 dark:text-gray-400 text-sm mb-4">{description}</p>
        <Link href={link} className="text-amber-500 hover:underline font-medium flex items-center gap-1">
          Explore <i className="ri-arrow-right-line"></i>
        </Link>
      </div>
    </div>
  );
}

export default function Categories() {
  const { t } = useTranslation();
  
  const categories = [
    {
      title: t('categories.whyIslam'),
      description: t('categories.whyIslamDesc'),
      imageUrl: "https://images.unsplash.com/photo-1619536401168-de7600a28c9b?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      link: "#why-islam"
    },
    {
      title: t('categories.refutations'),
      description: t('categories.refutationsDesc'),
      imageUrl: "https://images.unsplash.com/photo-1564121211835-e88c852648ab?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      link: "#refutations"
    },
    {
      title: t('categories.multimedia'),
      description: t('categories.multimediaDesc'),
      imageUrl: "https://images.unsplash.com/photo-1594839343055-ed490ba99faa?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      link: "#multimedia"
    },
    {
      title: t('categories.submit'),
      description: t('categories.submitDesc'),
      imageUrl: "https://images.unsplash.com/photo-1618019259202-428833da3c8d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
      link: "#submit"
    }
  ];
  
  return (
    <section className="py-12 bg-white dark:bg-slate-900">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">{t('categories.title')}</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            {t('categories.description')}
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => (
            <CategoryCard 
              key={index}
              title={category.title}
              description={category.description}
              imageUrl={category.imageUrl}
              link={category.link}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
