import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

export default function Hero() {
  const { t } = useTranslation();
  
  return (
    <section 
      className="text-white py-16 md:py-24 bg-cover bg-center bg-no-repeat"
      style={{ 
        backgroundImage: `linear-gradient(rgba(15, 23, 42, 0.7), rgba(15, 23, 42, 0.7)), url('https://images.unsplash.com/photo-1584807434751-3031a4a06283?ixlib=rb-1.2.1&auto=format&fit=crop&w=1200&q=80')`,
        backgroundBlendMode: 'overlay'
      }}
    >
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-serif">
            <span className="block mb-3">{t('hero.truth')}</span>
            <span className="text-amber-500">{t('hero.subtitle')}</span>
          </h1>
          <p className="text-lg md:text-xl opacity-90 max-w-2xl mx-auto">
            {t('hero.description')}
          </p>
          <div className="pt-4 flex flex-col sm:flex-row gap-3 justify-center">
            <Button 
              asChild
              size="lg"
              className="bg-amber-500 hover:bg-amber-600 text-white"
            >
              <Link href="#why-islam">
                Explore Evidence
              </Link>
            </Button>
            <Button 
              asChild
              size="lg" 
              variant="outline"
              className="bg-white/10 hover:bg-white/20 backdrop-blur-sm text-white border-white/30"
            >
              <Link href="#refutations">
                Browse Refutations
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
