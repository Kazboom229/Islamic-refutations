import { useTranslation } from "react-i18next";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";

interface EvidenceCardProps {
  icon: string;
  title: string;
  points: string[];
  link: string;
  linkText: string;
}

function EvidenceCard({ icon, title, points, link, linkText }: EvidenceCardProps) {
  return (
    <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md overflow-hidden">
      <div className="p-6">
        <div className="w-12 h-12 bg-blue-50 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-4">
          <i className={`${icon} text-2xl text-blue-700 dark:text-blue-400`}></i>
        </div>
        <h3 className="text-xl font-bold mb-3 text-gray-900 dark:text-white">{title}</h3>
        <ul className="space-y-3 text-gray-700 dark:text-gray-300">
          {points.map((point, index) => (
            <li key={index} className="flex items-start gap-2">
              <i className="ri-check-line text-emerald-500 mt-1"></i>
              <span>{point}</span>
            </li>
          ))}
        </ul>
        <Link href={link} className="mt-4 inline-flex items-center text-amber-500 hover:underline">
          <span>{linkText}</span>
          <i className="ri-arrow-right-line ml-1"></i>
        </Link>
      </div>
    </div>
  );
}

export default function WhyIslam() {
  const { t } = useTranslation();
  
  // Fetch 3D model data (if available)
  const { data: modelData } = useQuery({
    queryKey: ['/api/models/featured'],
    queryFn: async () => {
      const res = await fetch('/api/models/featured');
      if (!res.ok) return null;
      return res.json();
    }
  });
  
  const evidences = [
    {
      icon: "ri-earth-line",
      title: t('whyIslam.evidence1.title'),
      points: [
        t('whyIslam.evidence1.point1'),
        t('whyIslam.evidence1.point2'),
        t('whyIslam.evidence1.point3'),
        t('whyIslam.evidence1.point4')
      ],
      link: "/evidence/god",
      linkText: t('common.viewDetails')
    },
    {
      icon: "ri-book-open-line",
      title: t('whyIslam.evidence2.title'),
      points: [
        t('whyIslam.evidence2.point1'),
        t('whyIslam.evidence2.point2'),
        t('whyIslam.evidence2.point3'),
        t('whyIslam.evidence2.point4')
      ],
      link: "/evidence/islam",
      linkText: t('common.viewDetails')
    },
    {
      icon: "ri-user-star-line",
      title: t('whyIslam.evidence3.title'),
      points: [
        t('whyIslam.evidence3.point1'),
        t('whyIslam.evidence3.point2'),
        t('whyIslam.evidence3.point3'),
        t('whyIslam.evidence3.point4')
      ],
      link: "/evidence/prophet",
      linkText: t('common.viewDetails')
    }
  ];
  
  return (
    <section id="why-islam" className="py-16 bg-gray-50 dark:bg-slate-950">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <span className="text-amber-500 text-sm font-medium uppercase tracking-wider">Evidence & Proofs</span>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mt-2 mb-4">{t('whyIslam.title')}</h2>
          <p className="text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            {t('whyIslam.description')}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          {evidences.map((evidence, index) => (
            <EvidenceCard 
              key={index}
              icon={evidence.icon}
              title={evidence.title}
              points={evidence.points}
              link={evidence.link}
              linkText={evidence.linkText}
            />
          ))}
        </div>

        {/* Interactive Element */}
        <div className="bg-white dark:bg-slate-800 rounded-xl shadow-md p-6 md:p-8 overflow-hidden">
          <div className="flex flex-col md:flex-row gap-6 items-center">
            <div className="md:w-1/2">
              <span className="text-sm text-amber-500 font-medium uppercase tracking-wider">Interactive Learning</span>
              <h3 className="text-2xl font-bold mb-4 mt-1 text-gray-900 dark:text-white">
                {t('whyIslam.interactive.title')}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                {t('whyIslam.interactive.description')}
              </p>
              <div className="flex flex-wrap gap-3">
                <Button 
                  asChild
                  className="bg-blue-800 hover:bg-blue-900 text-white flex items-center gap-1"
                >
                  <Link href="/models">
                    <i className="ri-3d-cube-line"></i> View 3D Diagrams
                  </Link>
                </Button>
                <Button 
                  asChild
                  variant="outline"
                  className="text-gray-800 dark:text-gray-200 flex items-center gap-1"
                >
                  <Link href="/presentations">
                    <i className="ri-file-list-3-line"></i> Browse Presentations
                  </Link>
                </Button>
              </div>
            </div>
            <div className="md:w-1/2 relative h-64 md:h-80">
              <div className="absolute inset-0 bg-gray-100 dark:bg-slate-700 rounded-lg overflow-hidden flex items-center justify-center">
                {modelData ? (
                  // This would be replaced by actual 3D model viewer component
                  <iframe
                    title="3D Model Viewer"
                    src={modelData.embedUrl}
                    className="w-full h-full border-0"
                    allowFullScreen
                  ></iframe>
                ) : (
                  <div className="text-center p-4">
                    <i className="ri-cube-line text-6xl text-gray-400 dark:text-gray-600 mb-3"></i>
                    <p className="text-gray-500 dark:text-gray-400">Interactive 3D Model</p>
                    <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Click to interact</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
