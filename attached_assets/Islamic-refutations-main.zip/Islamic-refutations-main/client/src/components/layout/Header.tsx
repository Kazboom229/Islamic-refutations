import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { 
  useDarkMode, 
  useLanguageToggle, 
  useMobileMenu, 
  useSearchOverlay 
} from "@/lib/hooks";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { SearchOverlay } from "../ui/search-overlay";
import { useState, useEffect } from "react";
import { Sun, Moon, Menu, X, Search } from "lucide-react";

export default function Header() {
  const { t } = useTranslation();
  const [darkMode, setDarkMode] = useDarkMode();
  const { language, toggleLanguage } = useLanguageToggle();
  const [mobileMenuOpen, setMobileMenuOpen] = useMobileMenu();
  const [searchOpen, setSearchOpen] = useSearchOverlay();
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);

  useEffect(() => {
    // Check if user is logged in as admin from sessionStorage
    const adminToken = sessionStorage.getItem("adminToken");
    setIsAdmin(!!adminToken);
  }, []);

  const handleLogout = () => {
    sessionStorage.removeItem("adminToken");
    setIsAdmin(false);
    setAdminMenuOpen(false);
    window.location.href = "/";
  };

  return (
    <header className="sticky top-0 z-50 bg-white dark:bg-slate-900 shadow-md">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center">
          <Link href="/" className="flex items-center gap-2">
            <svg className="w-8 h-8 text-amber-500" fill="currentColor" viewBox="0 0 24 24">
              <path d="M12 2L1 21h22L12 2zm0 4.32L18.54 19H5.46L12 6.32zm-1 8.18v-4h2v4h-2zm0 4v-2h2v2h-2z"></path>
            </svg>
            <span className="text-xl font-bold bg-gradient-to-r from-amber-500 to-emerald-500 bg-clip-text text-transparent">Haqq</span>
          </Link>
        </div>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          <Link href="/" className="px-1 py-2 font-medium text-gray-700 dark:text-gray-200 hover:text-amber-500 dark:hover:text-amber-500 transition-colors">
            {t('nav.home')}
          </Link>
          <Link href="/#why-islam" className="px-1 py-2 font-medium text-gray-700 dark:text-gray-200 hover:text-amber-500 dark:hover:text-amber-500 transition-colors">
            {t('nav.whyIslam')}
          </Link>
          <Link href="/#refutations" className="px-1 py-2 font-medium text-gray-700 dark:text-gray-200 hover:text-amber-500 dark:hover:text-amber-500 transition-colors">
            {t('nav.refutations')}
          </Link>
          <Link href="/#multimedia" className="px-1 py-2 font-medium text-gray-700 dark:text-gray-200 hover:text-amber-500 dark:hover:text-amber-500 transition-colors">
            {t('nav.multimedia')}
          </Link>
          <Link href="/#submit" className="px-1 py-2 font-medium text-gray-700 dark:text-gray-200 hover:text-amber-500 dark:hover:text-amber-500 transition-colors">
            {t('nav.submit')}
          </Link>
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Search */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setSearchOpen(true)}
            aria-label="Search"
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Language Toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleLanguage}
            aria-label="Toggle Language"
          >
            <span className="font-medium">{language === 'en' ? 'EN' : 'SO'}</span>
          </Button>

          {/* Dark Mode Toggle */}
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setDarkMode(!darkMode)}
            aria-label="Toggle Dark Mode"
          >
            {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
          </Button>

          {/* Admin Button - Only visible to admins */}
          {isAdmin && (
            <DropdownMenu open={adminMenuOpen} onOpenChange={setAdminMenuOpen}>
              <DropdownMenuTrigger asChild>
                <Button 
                  className="hidden sm:block ml-1 bg-amber-500 text-white hover:bg-amber-600"
                  size="sm"
                >
                  Admin
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-64">
                <div className="p-3 border-b">
                  <p className="font-medium">{t('admin.dashboard')}</p>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Manage your content</p>
                </div>
                <DropdownMenuItem asChild>
                  <Link href="/admin/content/new" className="cursor-pointer">
                    <i className="ri-add-circle-line mr-2"></i> {t('admin.addContent')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/dashboard" className="cursor-pointer">
                    <i className="ri-edit-line mr-2"></i> {t('admin.manageContent')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/dashboard?type=media" className="cursor-pointer">
                    <i className="ri-file-upload-line mr-2"></i> {t('admin.uploadMedia')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/dashboard?type=submissions" className="cursor-pointer">
                    <i className="ri-question-answer-line mr-2"></i> {t('admin.reviewSubmissions')}
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="text-red-500 cursor-pointer" onClick={handleLogout}>
                  <i className="ri-logout-box-line mr-2"></i> {t('admin.logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}

          {/* Mobile Menu Button */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                aria-label="Toggle Menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="px-0">
              <div className="flex flex-col py-6">
                <Link href="/" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                  {t('nav.home')}
                </Link>
                <Link href="/#why-islam" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                  {t('nav.whyIslam')}
                </Link>
                <Link href="/#refutations" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                  {t('nav.refutations')}
                </Link>
                <Link href="/#multimedia" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                  {t('nav.multimedia')}
                </Link>
                <Link href="/#submit" className="px-6 py-3 font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                  {t('nav.submit')}
                </Link>
                {isAdmin && (
                  <Link href="/admin/dashboard" className="px-6 py-3 font-medium text-amber-500 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-md" onClick={() => setMobileMenuOpen(false)}>
                    {t('admin.dashboard')}
                  </Link>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Search Overlay */}
      <SearchOverlay isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </header>
  );
}
