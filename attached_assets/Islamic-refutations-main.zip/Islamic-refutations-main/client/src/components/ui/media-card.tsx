import { Link } from "wouter";
import { useTranslation } from "react-i18next";
import { 
  Card, 
  CardContent, 
  CardFooter,
  CardHeader
} from "@/components/ui/card";
import { Eye, Download, Clock, Share2, Code, Video, FileText, Image, SlidersHorizontal } from "lucide-react";
import { Button } from "./button";

interface MediaCardProps {
  id: number;
  title: string;
  description: string;
  type: 'presentation' | 'pdf' | '3d' | 'infographic' | 'video' | 'interactive';
  imageUrl: string;
  views: number;
  downloads?: number;
  duration?: string;
  sourceCode?: boolean;
  url: string;
}

export function MediaCard({ 
  id, 
  title, 
  description, 
  type, 
  imageUrl, 
  views,
  downloads,
  duration,
  sourceCode,
  url
}: MediaCardProps) {
  const { t } = useTranslation();
  
  // Map type to icon and label
  const typeInfo = {
    'presentation': { 
      icon: <SlidersHorizontal className="h-4 w-4" />, 
      label: 'Presentation',
      action: t('common.view')
    },
    'pdf': { 
      icon: <FileText className="h-4 w-4" />, 
      label: 'PDF',
      action: t('common.download')
    },
    '3d': { 
      icon: <i className="ri-3d-cube-line" />, 
      label: '3D Diagram',
      action: t('common.explore')
    },
    'infographic': { 
      icon: <Image className="h-4 w-4" />, 
      label: 'Infographic',
      action: t('common.view')
    },
    'video': { 
      icon: <Video className="h-4 w-4" />, 
      label: 'Video',
      action: t('common.watch')
    },
    'interactive': { 
      icon: <Code className="h-4 w-4" />, 
      label: 'Interactive',
      action: t('common.try')
    }
  };
  
  return (
    <Card className="overflow-hidden group h-full flex flex-col">
      <div className="h-48 overflow-hidden relative">
        <img 
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
          <div>
            <span className="px-2 py-1 rounded text-xs font-medium bg-white/20 backdrop-blur-sm text-white">
              {typeInfo[type].icon}
              <span className="ml-1">{typeInfo[type].label}</span>
            </span>
            <h3 className="text-white text-lg font-bold mt-2">{title}</h3>
          </div>
        </div>
        
        {/* Play button for videos */}
        {type === 'video' && (
          <a 
            href={url} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="absolute inset-0 m-auto w-16 h-16 flex items-center justify-center bg-amber-500/80 hover:bg-amber-500 text-white rounded-full transition-colors backdrop-blur-sm"
          >
            <i className="ri-play-fill text-2xl ml-1"></i>
          </a>
        )}
      </div>
      
      <CardContent className="p-5 flex-1">
        <p className="text-gray-600 dark:text-gray-400 text-sm line-clamp-2 mb-4">
          {description}
        </p>
      </CardContent>
      
      <CardFooter className="p-5 pt-0 flex justify-between items-center">
        <Link href={url}>
          <Button variant="link" className="text-amber-500 hover:text-amber-600 p-0 flex items-center gap-1">
            {typeInfo[type].action} {typeInfo[type].icon}
          </Button>
        </Link>
        
        <div className="flex items-center gap-2 text-xs text-gray-500 dark:text-gray-400">
          {downloads !== undefined && (
            <span className="flex items-center gap-1">
              <Download className="h-3 w-3" /> {downloads}
            </span>
          )}
          
          {duration && (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" /> {duration}
            </span>
          )}
          
          {sourceCode && (
            <span className="flex items-center gap-1">
              <i className="ri-github-line mr-1"></i> Open Source
            </span>
          )}
          
          <span className="flex items-center gap-1">
            <Eye className="h-3 w-3" /> {views}
          </span>
        </div>
      </CardFooter>
    </Card>
  );
}
