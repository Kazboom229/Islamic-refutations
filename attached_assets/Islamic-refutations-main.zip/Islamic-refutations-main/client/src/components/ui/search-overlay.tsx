import { useState, useEffect, useRef } from 'react';
import { useTranslation } from 'react-i18next';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Search, X } from 'lucide-react';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const { t } = useTranslation();
  const [searchTerm, setSearchTerm] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  const { data: searchResults, isLoading } = useQuery({
    queryKey: ['/api/search', searchTerm],
    queryFn: async () => {
      if (!searchTerm || searchTerm.length < 2) return [];
      const res = await fetch(`/api/search?q=${encodeURIComponent(searchTerm)}`);
      if (!res.ok) throw new Error('Search failed');
      return res.json();
    },
    enabled: searchTerm.length >= 2
  });
  
  // Focus input when overlay opens
  useEffect(() => {
    if (isOpen && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isOpen]);
  
  // Handle click outside to close
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (isOpen && e.target instanceof Element && !e.target.closest('.search-content')) {
        onClose();
      }
    };
    
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);
  
  if (!isOpen) return null;
  
  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-start justify-center pt-16 px-4">
      <div className="search-content container bg-white dark:bg-slate-900 shadow-lg p-4 rounded-lg animate-in fade-in-0 slide-in-from-top-5">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">{t('common.search')}</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="relative">
          <Input
            ref={inputRef}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search for topics, questions, or keywords..."
            className="w-full px-10 py-6 text-base"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
          {searchTerm && (
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute right-2 top-1/2 transform -translate-y-1/2"
              onClick={() => setSearchTerm('')}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>
        
        {searchTerm.length >= 2 && (
          <div className="mt-4 max-h-[60vh] overflow-y-auto">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-amber-500 mx-auto"></div>
                <p className="mt-2 text-gray-500">Searching...</p>
              </div>
            ) : searchResults && searchResults.length > 0 ? (
              <div className="space-y-3">
                {searchResults.map((result: any) => (
                  <Link 
                    key={result.id} 
                    href={`/content/${result.id}`}
                    onClick={onClose}
                  >
                    <div className="p-3 hover:bg-gray-100 dark:hover:bg-slate-800 rounded-md cursor-pointer">
                      <p className="font-medium">{result.title}</p>
                      <p className="text-sm text-gray-500 line-clamp-1">{result.summary}</p>
                      <div className="flex items-center mt-1">
                        <span className="text-xs px-2 py-0.5 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-200 rounded-full">
                          {result.category}
                        </span>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">No results found for "{searchTerm}"</p>
              </div>
            )}
          </div>
        )}
        
        <div className="mt-3 text-sm text-gray-500 dark:text-gray-400 flex flex-wrap gap-2">
          <span>Popular:</span>
          <a href="#" onClick={() => { setSearchTerm('Atheism'); return false; }} className="text-amber-500 hover:underline">Atheism</a>
          <a href="#" onClick={() => { setSearchTerm('Misconceptions'); return false; }} className="text-amber-500 hover:underline">Misconceptions</a>
          <a href="#" onClick={() => { setSearchTerm('Evidence'); return false; }} className="text-amber-500 hover:underline">Evidence</a>
        </div>
      </div>
    </div>
  );
}
