import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useTranslation } from "react-i18next";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Check, Loader2 } from "lucide-react";

const contentTypes = [
  { value: "refutation", label: "Refutation" },
  { value: "evidence", label: "Evidence" },
  { value: "article", label: "Article" },
];

const contentCategories = [
  { value: "philosophical", label: "Philosophical" },
  { value: "historical", label: "Historical" },
  { value: "quranic", label: "Qur'anic" },
  { value: "ideological", label: "Modern Ideological" },
  { value: "scientific", label: "Scientific" },
  { value: "global", label: "Global Narratives" },
];

// Form schema with validation
const FormSchema = z.object({
  title_en: z.string().min(3, { message: "Title must be at least 3 characters" }),
  title_so: z.string().optional(),
  summary_en: z.string().min(10, { message: "Summary must be at least 10 characters" }),
  summary_so: z.string().optional(),
  content_en: z.string().min(20, { message: "Content must be at least 20 characters" }),
  content_so: z.string().optional(),
  category: z.string().min(1, { message: "Please select a category" }),
  type: z.string().min(1, { message: "Please select a content type" }),
  tags: z.array(z.string()).optional(),
  featured: z.boolean().default(false),
  published: z.boolean().default(false),
});

export default function ContentForm() {
  const [, navigate] = useLocation();
  const params = useParams<{ id: string }>();
  const isEditing = !!params.id;
  const { t } = useTranslation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [token, setToken] = useState<string | null>(null);
  const [languageTab, setLanguageTab] = useState("english");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState<string[]>([]);

  // Form setup
  const form = useForm<z.infer<typeof FormSchema>>({
    resolver: zodResolver(FormSchema),
    defaultValues: {
      title_en: "",
      title_so: "",
      summary_en: "",
      summary_so: "",
      content_en: "",
      content_so: "",
      category: "",
      type: "",
      tags: [],
      featured: false,
      published: false,
    },
  });

  // Check authentication on mount
  useEffect(() => {
    const adminToken = sessionStorage.getItem("adminToken");
    
    if (!adminToken) {
      navigate("/admin");
      return;
    }
    
    setToken(adminToken);
  }, [navigate]);

  // Fetch content if editing
  const { data: contentData, isLoading: isLoadingContent } = useQuery({
    queryKey: [`/api/admin/content/${params.id}`],
    queryFn: async () => {
      if (!token || !isEditing) return null;
      const res = await fetch(`/api/admin/content/${params.id}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (!res.ok) throw new Error('Failed to fetch content');
      return res.json();
    },
    enabled: !!token && isEditing,
  });

  // Update form when content data is loaded
  useEffect(() => {
    if (contentData) {
      form.reset({
        title_en: contentData.title_en,
        title_so: contentData.title_so || "",
        summary_en: contentData.summary_en,
        summary_so: contentData.summary_so || "",
        content_en: contentData.content_en,
        content_so: contentData.content_so || "",
        category: contentData.category,
        type: contentData.type,
        tags: contentData.tags || [],
        featured: contentData.featured,
        published: contentData.published,
      });
      setTags(contentData.tags || []);
    }
  }, [contentData, form]);

  // Create content mutation
  const createContentMutation = useMutation({
    mutationFn: async (data: z.infer<typeof FormSchema>) => {
      return apiRequest("POST", "/api/admin/content", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/contents'] });
      toast({
        title: "Content created",
        description: "Your content has been successfully created.",
      });
      navigate("/admin/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to create content: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Update content mutation
  const updateContentMutation = useMutation({
    mutationFn: async (data: z.infer<typeof FormSchema>) => {
      return apiRequest("PUT", `/api/admin/content/${params.id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/contents'] });
      queryClient.invalidateQueries({ queryKey: [`/api/admin/content/${params.id}`] });
      toast({
        title: "Content updated",
        description: "Your content has been successfully updated.",
      });
      navigate("/admin/dashboard");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: `Failed to update content: ${error.message}`,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: z.infer<typeof FormSchema>) => {
    // Include tags
    data.tags = tags;
    
    if (isEditing) {
      updateContentMutation.mutate(data);
    } else {
      createContentMutation.mutate(data);
    }
  };

  // Tag management
  const addTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const removeTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  // Check if form is submitting
  const isSubmitting = createContentMutation.isPending || updateContentMutation.isPending;

  if (!token) {
    return null; // Will redirect to login
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={() => navigate("/admin/dashboard")}
          className="mr-2"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Back
        </Button>
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
          {isEditing ? "Edit Content" : "Add New Content"}
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Content Details</CardTitle>
              <CardDescription>
                {isEditing 
                  ? "Update your content information below" 
                  : "Enter the details for your new content"}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingContent && isEditing ? (
                <div className="flex justify-center py-8">
                  <Loader2 className="h-8 w-8 animate-spin text-amber-500" />
                </div>
              ) : (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <Tabs value={languageTab} onValueChange={setLanguageTab}>
                      <TabsList className="mb-6">
                        <TabsTrigger value="english">English</TabsTrigger>
                        <TabsTrigger value="somali">Somali</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="english" className="space-y-6">
                        <FormField
                          control={form.control}
                          name="title_en"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Title (English)*</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter title" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="summary_en"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Summary (English)*</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Enter a brief summary" 
                                  rows={3}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="content_en"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Content (English)*</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Enter the main content" 
                                  rows={10}
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TabsContent>
                      
                      <TabsContent value="somali" className="space-y-6">
                        <FormField
                          control={form.control}
                          name="title_so"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Title (Somali)</FormLabel>
                              <FormControl>
                                <Input 
                                  placeholder="Enter title in Somali" 
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Optional: Leave blank if not available yet
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="summary_so"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Summary (Somali)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Enter a brief summary in Somali" 
                                  rows={3}
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Optional: Leave blank if not available yet
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="content_so"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Content (Somali)</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Enter the main content in Somali" 
                                  rows={10}
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Optional: Leave blank if not available yet
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </TabsContent>
                    </Tabs>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Content Type*</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select content type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {contentTypes.map(type => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="category"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Category*</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                              value={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select category" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {contentCategories.map(category => (
                                  <SelectItem key={category.value} value={category.value}>
                                    {category.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div>
                      <FormLabel>Tags</FormLabel>
                      <div className="flex gap-2 mt-1 mb-2">
                        <Input 
                          value={tagInput}
                          onChange={(e) => setTagInput(e.target.value)}
                          placeholder="Add a tag"
                          onKeyDown={(e) => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addTag();
                            }
                          }}
                        />
                        <Button 
                          type="button" 
                          variant="outline" 
                          onClick={addTag}
                        >
                          Add
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {tags.map(tag => (
                          <div 
                            key={tag} 
                            className="bg-gray-100 dark:bg-gray-800 text-gray-800 dark:text-gray-200 px-2 py-1 rounded-md flex items-center gap-1"
                          >
                            {tag}
                            <button 
                              type="button"
                              onClick={() => removeTag(tag)}
                              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
                            >
                              &times;
                            </button>
                          </div>
                        ))}
                        {tags.length === 0 && (
                          <p className="text-sm text-gray-500 dark:text-gray-400">
                            No tags added yet
                          </p>
                        )}
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-amber-500 hover:bg-amber-600 mt-4"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {isEditing ? 'Updating...' : 'Creating...'}
                        </>
                      ) : (
                        <>
                          <Check className="mr-2 h-4 w-4" />
                          {isEditing ? 'Update Content' : 'Create Content'}
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Publishing Options</CardTitle>
              <CardDescription>
                Configure how your content will be displayed
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <FormField
                control={form.control}
                name="featured"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Featured Content</FormLabel>
                      <FormDescription>
                        Featured content will be highlighted on the home page
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="published"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md p-4 border">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>Publish Content</FormLabel>
                      <FormDescription>
                        When enabled, content will be visible to site visitors
                      </FormDescription>
                    </div>
                  </FormItem>
                )}
              />
              
              <Separator />
              
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Content Status</h3>
                <div className="text-sm text-gray-500 dark:text-gray-400">
                  {isEditing ? (
                    <div>
                      <p>Created: {contentData ? new Date(contentData.createdAt).toLocaleString() : 'Loading...'}</p>
                      <p>Last Updated: {contentData ? new Date(contentData.updatedAt).toLocaleString() : 'Loading...'}</p>
                      <p>Views: {contentData?.views || 0}</p>
                    </div>
                  ) : (
                    <p>This content has not been created yet</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
