import Hero from "@/components/home/Hero";
import Categories from "@/components/home/Categories";
import WhyIslam from "@/components/home/WhyIslam";
import Refutations from "@/components/home/Refutations";
import Multimedia from "@/components/home/Multimedia";
import SubmitQuestion from "@/components/home/SubmitQuestion";
import FAQ from "@/components/home/FAQ";
import { useEffect } from "react";

export default function Home() {
  // Handle anchor links scrolling behavior
  useEffect(() => {
    const handleHashChange = () => {
      const { hash } = window.location;
      if (hash) {
        // Wait for DOM to be ready
        setTimeout(() => {
          const element = document.querySelector(hash);
          if (element) {
            // Scroll to element with a slight offset for the header
            window.scrollTo({
              top: element.getBoundingClientRect().top + window.scrollY - 100,
              behavior: 'smooth'
            });
          }
        }, 0);
      }
    };

    // Run once on mount in case there's a hash in the URL
    handleHashChange();

    // Add event listener for hash changes
    window.addEventListener('hashchange', handleHashChange);
    
    return () => {
      window.removeEventListener('hashchange', handleHashChange);
    };
  }, []);

  return (
    <>
      <Hero />
      <Categories />
      <WhyIslam />
      <Refutations />
      <Multimedia />
      <SubmitQuestion />
      <FAQ />
    </>
  );
}
