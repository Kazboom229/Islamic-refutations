import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { insertContentSchema, insertMediaSchema, insertQuestionSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import { ZodError } from "zod";

// Simple JWT implementation for admin auth
const generateToken = () => {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
};

// Store active tokens
const activeTokens: string[] = [];

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = app.route("/api");

  // Authentication routes
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);

      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // In a real app, we would compare hashed passwords
      if (user.password !== password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }

      // Check if user is admin
      if (!user.isAdmin) {
        return res.status(403).json({ message: "Access denied: not an admin user" });
      }

      // Generate and store token
      const token = generateToken();
      activeTokens.push(token);

      res.json({ token, user: { id: user.id, username: user.username } });
    } catch (error) {
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    const { token } = req.body;

    if (token) {
      const index = activeTokens.indexOf(token);
      if (index > -1) {
        activeTokens.splice(index, 1);
      }
    }

    res.json({ message: "Logged out successfully" });
  });

  // Middleware to check authentication for admin routes
  const authenticateAdmin = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      return res.status(401).json({ message: "Authentication required" });
    }

    const token = authHeader.split(" ")[1];

    if (!token || !activeTokens.includes(token)) {
      return res.status(401).json({ message: "Invalid or expired token" });
    }

    next();
  };

  // Content routes
  app.get("/api/contents", async (req, res) => {
    try {
      const { category, type } = req.query;
      const published = true; // Public API only returns published content

      const contents = await storage.getContents({
        category: category as string,
        type: type as string,
        published
      });

      res.json(contents);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve contents" });
    }
  });

  app.get("/api/content/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const content = await storage.getContent(id);

      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      if (!content.published) {
        return res.status(404).json({ message: "Content not found" });
      }

      // Increment view count
      await storage.incrementViews(id);

      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve content" });
    }
  });

  // Protected admin routes for content management
  app.get("/api/admin/contents", authenticateAdmin, async (req, res) => {
    try {
      const { category, type, published } = req.query;

      const contents = await storage.getContents({
        category: category as string,
        type: type as string,
        published: published === "true" ? true : published === "false" ? false : undefined
      });

      res.json(contents);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve contents" });
    }
  });

  app.get("/api/admin/content/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const content = await storage.getContent(id);

      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      res.json(content);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve content" });
    }
  });

  app.post("/api/admin/content", authenticateAdmin, async (req, res) => {
    try {
      const contentData = insertContentSchema.parse(req.body);
      const content = await storage.createContent(contentData);
      res.status(201).json(content);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create content" });
    }
  });

  app.put("/api/admin/content/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const contentData = insertContentSchema.partial().parse(req.body);
      const content = await storage.updateContent(id, contentData);

      if (!content) {
        return res.status(404).json({ message: "Content not found" });
      }

      res.json(content);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update content" });
    }
  });

  app.delete("/api/admin/content/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const deleted = await storage.deleteContent(id);

      if (!deleted) {
        return res.status(404).json({ message: "Content not found" });
      }

      res.json({ message: "Content deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete content" });
    }
  });

  // Media routes
  app.get("/api/media", async (req, res) => {
    try {
      const { type } = req.query;
      const published = true; // Public API only returns published media

      const mediaItems = await storage.getMediaItems({
        type: type as string,
        published
      });

      res.json(mediaItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve media items" });
    }
  });

  app.get("/api/media/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const media = await storage.getMedia(id);

      if (!media) {
        return res.status(404).json({ message: "Media not found" });
      }

      if (!media.published) {
        return res.status(404).json({ message: "Media not found" });
      }

      // Increment view count
      await storage.incrementMediaViews(id);

      res.json(media);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve media" });
    }
  });

  app.get("/api/media/:id/download", async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const media = await storage.getMedia(id);

      if (!media) {
        return res.status(404).json({ message: "Media not found" });
      }

      if (!media.published) {
        return res.status(404).json({ message: "Media not found" });
      }

      // Increment download count
      await storage.incrementMediaDownloads(id);

      // In a real app, we would serve the file
      // For now, just redirect to the URL
      res.redirect(media.url);
    } catch (error) {
      res.status(500).json({ message: "Failed to download media" });
    }
  });

  app.get("/api/models/featured", async (req, res) => {
    try {
      const mediaItems = await storage.getMediaItems({
        type: "3d",
        published: true
      });

      // Return the first featured 3D model or null
      const featuredModel = mediaItems.find(item => item.featured) || mediaItems[0] || null;

      if (featuredModel) {
        res.json({
          ...featuredModel,
          embedUrl: featuredModel.url // In a real app, this would be a proper embed URL
        });
      } else {
        res.json(null);
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve featured model" });
    }
  });

  // Protected admin routes for media management
  app.get("/api/admin/media", authenticateAdmin, async (req, res) => {
    try {
      const { type, published } = req.query;

      const mediaItems = await storage.getMediaItems({
        type: type as string,
        published: published === "true" ? true : published === "false" ? false : undefined
      });

      res.json(mediaItems);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve media items" });
    }
  });

  app.get("/api/admin/media/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const media = await storage.getMedia(id);

      if (!media) {
        return res.status(404).json({ message: "Media not found" });
      }

      res.json(media);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve media" });
    }
  });

  app.post("/api/admin/media", authenticateAdmin, async (req, res) => {
    try {
      const mediaData = insertMediaSchema.parse(req.body);
      const media = await storage.createMedia(mediaData);
      res.status(201).json(media);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create media" });
    }
  });

  app.put("/api/admin/media/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const mediaData = insertMediaSchema.partial().parse(req.body);
      const media = await storage.updateMedia(id, mediaData);

      if (!media) {
        return res.status(404).json({ message: "Media not found" });
      }

      res.json(media);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to update media" });
    }
  });

  app.delete("/api/admin/media/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const deleted = await storage.deleteMedia(id);

      if (!deleted) {
        return res.status(404).json({ message: "Media not found" });
      }

      res.json({ message: "Media deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete media" });
    }
  });

  // Question submission routes
  app.post("/api/questions", async (req, res) => {
    try {
      const questionData = insertQuestionSchema.parse(req.body);
      const question = await storage.createQuestion(questionData);
      res.status(201).json({ message: "Question submitted successfully", id: question.id });
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to submit question" });
    }
  });

  // File upload route (mock for now)
  app.post("/api/upload", (req, res) => {
    // In a real app, we would handle file upload here
    // For now, just return a mock URL
    res.json({ fileUrl: `/uploads/file-${Date.now()}.pdf` });
  });

  // Search route
  app.get("/api/search", async (req, res) => {
    try {
      const { q } = req.query;

      if (!q || typeof q !== "string") {
        return res.status(400).json({ message: "Search query is required" });
      }

      const results = await storage.searchContents(q);

      // Only return published content in search results
      const publishedResults = results.filter(content => content.published);

      res.json(publishedResults);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Protected admin routes for question management
  app.get("/api/admin/questions", authenticateAdmin, async (req, res) => {
    try {
      const { status } = req.query;

      const questions = await storage.getQuestions({
        status: status as string
      });

      res.json(questions);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve questions" });
    }
  });

  app.get("/api/admin/question/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const question = await storage.getQuestion(id);

      if (!question) {
        return res.status(404).json({ message: "Question not found" });
      }

      res.json(question);
    } catch (error) {
      res.status(500).json({ message: "Failed to retrieve question" });
    }
  });

  app.put("/api/admin/question/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const { status, answer } = req.body;

      if (!["pending", "answered", "rejected"].includes(status)) {
        return res.status(400).json({ message: "Invalid status" });
      }

      if (status === "answered" && !answer) {
        return res.status(400).json({ message: "Answer is required when status is 'answered'" });
      }

      const question = await storage.updateQuestion(id, { status, answer });

      if (!question) {
        return res.status(404).json({ message: "Question not found" });
      }

      res.json(question);
    } catch (error) {
      res.status(500).json({ message: "Failed to update question" });
    }
  });

  app.delete("/api/admin/question/:id", authenticateAdmin, async (req, res) => {
    try {
      const id = parseInt(req.params.id);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ID format" });
      }

      const deleted = await storage.deleteQuestion(id);

      if (!deleted) {
        return res.status(404).json({ message: "Question not found" });
      }

      res.json({ message: "Question deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete question" });
    }
  });

  // Initialize HTTP server
  const httpServer = createServer(app);
  return httpServer;
}