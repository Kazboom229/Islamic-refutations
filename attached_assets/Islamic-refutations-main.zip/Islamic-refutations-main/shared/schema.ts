import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User model for authentication
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Content model for articles, refutations, and evidence
export const contents = pgTable("contents", {
  id: serial("id").primaryKey(),
  title_en: text("title_en").notNull(),
  title_so: text("title_so"),
  summary_en: text("summary_en").notNull(),
  summary_so: text("summary_so"),
  content_en: text("content_en").notNull(),
  content_so: text("content_so"),
  category: text("category").notNull(), // philosophical, historical, quranic, ideological, scientific, global
  type: text("type").notNull(), // refutation, evidence, article
  tags: text("tags").array(),
  views: integer("views").default(0),
  featured: boolean("featured").default(false),
  published: boolean("published").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertContentSchema = createInsertSchema(contents).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  views: true,
});

// Media model for multimedia content
export const media = pgTable("media", {
  id: serial("id").primaryKey(),
  title_en: text("title_en").notNull(),
  title_so: text("title_so"),
  description_en: text("description_en").notNull(),
  description_so: text("description_so"),
  type: text("type").notNull(), // presentation, pdf, 3d, infographic, video, interactive
  url: text("url").notNull(),
  imageUrl: text("image_url").notNull(),
  downloads: integer("downloads").default(0),
  views: integer("views").default(0),
  duration: text("duration"),
  sourceCode: boolean("source_code").default(false),
  featured: boolean("featured").default(false),
  published: boolean("published").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertMediaSchema = createInsertSchema(media).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  views: true,
  downloads: true,
});

// Questions model for user submitted questions
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  category: text("category").notNull(),
  question: text("question").notNull(),
  attachment: text("attachment"),
  status: text("status").default("pending"), // pending, answered, rejected
  answer: text("answer"),
  answeredBy: integer("answered_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertQuestionSchema = createInsertSchema(questions).omit({
  id: true,
  status: true,
  answer: true,
  answeredBy: true,
  createdAt: true,
  updatedAt: true,
});

// Define types based on the schemas
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Content = typeof contents.$inferSelect;
export type InsertContent = z.infer<typeof insertContentSchema>;

export type Media = typeof media.$inferSelect;
export type InsertMedia = z.infer<typeof insertMediaSchema>;

export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
